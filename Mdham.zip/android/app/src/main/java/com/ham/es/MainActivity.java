package com.ham.es;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
